import eventsystem.EventHandler;
import eventsystem.EventManager;
import eventsystem.Listener;

import eventsystem.events.BasicEvent;
import eventsystem.events.ComplexEvent;

import serialization.exceptions.BytesNotMatchingException;

import java.util.Arrays;

public class Main {
	
	public static class TestClass implements Listener {
		
		@EventHandler
		public void onTest(BasicEvent e) {
			System.out.println(e.getText());
		}
		
		@EventHandler
		public void onHallo(ComplexEvent e) {
			System.out.println("Moinsen");
		}
		
		@EventHandler
		public void onTest2(BasicEvent e) {
			System.out.println(e.getNumber());
		}
		
		public void onRip(BasicEvent e) {
			System.out.println("Rip");
		}
		
	}
	
	public static EventManager manager;

	public static void main(String[] args) throws BytesNotMatchingException {
		
		manager = new EventManager();
		manager.registerListeners(new TestClass());
		
		Main.manager.call(new BasicEvent("Test", 1));
		Main.manager.call(new ComplexEvent(new int[] {1, 2, 3}, new BasicEvent("Test23", 1)));
		
		
		
	}
	
}