package eventsystem;

/**
* This interface is to be implemented if you want to create your own Listeners.
*
* @author Cedric Wellhausen
* @version June 11 2020
*/
public interface Listener {}